const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

const db = require("./database/database");
const pool = require("./database/postgres");

// Routes
const authRoutes = require("./routes/authRoutes");
const contractorRoutes = require("./routes/contractorRoutes");
const securityRoutes = require("./routes/securityRoutes");
const reviewRoutes = require("./routes/reviewRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");
const adminRoutes = require("./routes/adminRoutes");

const app = express();

/* ===========================
   DATABASE SETUP
=========================== */

db.serialize(() => {

  // USERS TABLE
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT,
      last_name TEXT,
      email TEXT UNIQUE,
      password TEXT,
      role TEXT,
      failed_attempts INTEGER DEFAULT 0,
      locked_until INTEGER DEFAULT 0
    )
  `);

  // Add columns for existing databases
  db.run("ALTER TABLE users ADD COLUMN failed_attempts INTEGER DEFAULT 0", () => {});
  db.run("ALTER TABLE users ADD COLUMN locked_until INTEGER DEFAULT 0", () => {});

  // CONTRACTORS
  db.run(`
    CREATE TABLE IF NOT EXISTS contractors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company TEXT,
      specialty TEXT,
      city TEXT,
      phone TEXT,
      rating REAL
    )
  `);

  // ESTIMATES
  db.run(`
    CREATE TABLE IF NOT EXISTS estimates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT,
      contractor_id INTEGER,
      project_type TEXT,
      description TEXT,
      budget REAL,
      status TEXT
    )
  `);

  // REVIEWS
  db.run(`
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      rating INTEGER NOT NULL,
      comment TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // SECURITY LOGS
  db.run(`
    CREATE TABLE IF NOT EXISTS security_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT,
      status TEXT,
      ip_address TEXT,
      event_time DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // SAMPLE CONTRACTORS

  db.run(`
    INSERT OR IGNORE INTO contractors
    (id, company, specialty, city, phone, rating)
    VALUES
    (1,'Mike''s Construction','Kitchen Remodeling','Paterson','973-555-1001',4.9)
  `);

  db.run(`
    INSERT OR IGNORE INTO contractors
    (id, company, specialty, city, phone, rating)
    VALUES
    (2,'Elite Roofing','Roof Repair','Clifton','973-555-2002',4.8)
  `);

  db.run(`
    INSERT OR IGNORE INTO contractors
    (id, company, specialty,city,phone,rating)
    VALUES
    (3,'Garden State Plumbing','Plumbing','Newark','973-555-3003',5.0)
  `);

});

/* ===========================
   SECURITY
=========================== */

app.disable("x-powered-by");

app.use(helmet());

const limiter = rateLimit({

  windowMs: 15 * 60 * 1000,

  max: 100,

  standardHeaders: true,

  legacyHeaders: false,

  message: {
    error: "Too many requests. Please try again later."
  }

});

app.use(limiter);

const allowedOrigins = [

  "http://localhost:5173",

  "http://localhost:5174",

  "https://buildbid-pdbp.onrender.com"

];

app.use(cors({

  origin(origin, callback) {

    if (!origin || allowedOrigins.includes(origin)) {

      callback(null, true);

    } else {

      callback(new Error("CORS Not Allowed"));

    }

  },

  credentials: true,

  methods: ["GET","POST","PUT","DELETE"]

}));

app.use(express.json());

/* ===========================
   ROUTES
=========================== */

app.use("/api/auth", authRoutes);

app.use("/api/contractors", contractorRoutes);

app.use("/api/security", securityRoutes);

app.use("/api/reviews", reviewRoutes);

app.use("/api/dashboard", dashboardRoutes);

app.use("/api/admin", adminRoutes);

/* ===========================
   HOME
=========================== */

app.get("/", (req,res)=>{

  res.json({

    project:"BuildBid",

    status:"API Running",

    version:"1.0"

  });

});

/* ===========================
   DATABASE TEST
=========================== */

app.get("/api/test",(req,res)=>{

  db.all(

    "SELECT name FROM sqlite_master WHERE type='table'",

    [],

    (err,rows)=>{

      if(err){

        return res.status(500).json(err);

      }

      res.json(rows);

    }

  );

});

/* ===========================
   TEMP USERS
=========================== */

app.get("/api/users",(req,res)=>{

  db.all(

    "SELECT * FROM users",

    [],

    (err,rows)=>{

      if(err){

        return res.status(500).json(err);

      }

      res.json(rows);

    }

  );

});

/* ===========================
   START SERVER
=========================== */

app.get("/api/postgres-test", async (req, res) => {
  try {
    const result = await pool.query(
      "INSERT INTO users (first_name, last_name, email, password, role) VALUES ($1,$2,$3,$4,$5) RETURNING *",
      [
        "Test",
        "User",
        `test${Date.now()}@buildbid.com`,
        "password",
        "customer",
      ]
    );

    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: err.message,
    });
  }
});
const PORT = process.env.PORT || 5000;

app.listen(PORT,()=>{

  console.log(`✅ BuildBid Server running on http://localhost:${PORT}`);

});